import { Canvas, useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Environment, Lightformer } from "@react-three/drei";
import { useRef } from "react";
import type { Mesh, Group } from "three";

function Shapes() {
  const group = useRef<Group>(null);
  const knot = useRef<Mesh>(null);
  useFrame((state, delta) => {
    const d = Math.min(delta, 0.05);
    if (knot.current) { knot.current.rotation.x += d * 0.2; knot.current.rotation.y += d * 0.3; }
    if (group.current) {
      group.current.rotation.y += (state.pointer.x * 0.4 - group.current.rotation.y) * 0.05;
      group.current.rotation.x += (-state.pointer.y * 0.3 - group.current.rotation.x) * 0.05;
    }
  });
  return (
    <group position={[2.2, 0, 0]} scale={0.75}><group ref={group}>
      <Float speed={1.5} floatIntensity={1.2}>
        <mesh ref={knot}>
          <torusKnotGeometry args={[1.1, 0.35, 220, 32]} />
          <meshStandardMaterial color="#ff8a4c" metalness={0.6} roughness={0.2} />
        </mesh>
      </Float>
      <Float speed={2} floatIntensity={2} position={[2.6, 1.3, -1]}>
        <mesh><icosahedronGeometry args={[0.55, 0]} /><meshStandardMaterial color="#5fd4d0" metalness={0.3} roughness={0.3} flatShading /></mesh>
      </Float>
      <Float speed={1.2} floatIntensity={1.5} position={[-2.6, -1.1, -0.5]}>
        <mesh><sphereGeometry args={[0.6, 64, 64]} /><MeshDistortMaterial color="#ffc857" distort={0.4} speed={2} roughness={0.2} /></mesh>
      </Float>
      <Float speed={1.8} floatIntensity={1} position={[-2.2, 1.6, -1.5]}>
        <mesh><octahedronGeometry args={[0.4]} /><meshStandardMaterial color="#e8e3d9" metalness={0.8} roughness={0.15} /></mesh>
      </Float>
      <Float speed={1.4} floatIntensity={1.4} position={[2.3, -1.5, -0.8]}>
        <mesh><torusGeometry args={[0.45, 0.15, 24, 64]} /><meshStandardMaterial color="#ff8a4c" metalness={0.5} roughness={0.25} /></mesh>
      </Float>
    </group></group>
  );
}

export default function HeroScene() {
  return (
    <Canvas camera={{ position: [0, 0, 6], fov: 45 }} dpr={[1, 2]}
      onCreated={({ gl }) => gl.domElement.parentElement?.parentElement?.setAttribute("data-scene-ready", "")}>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={1.5} />
      <pointLight position={[-4, -2, 3]} intensity={20} color="#5fd4d0" />
      <Shapes />
      <Environment>
        <Lightformer intensity={2} position={[0, 5, 0]} scale={[10, 10, 1]} />
        <Lightformer intensity={1} color="#ffb38a" position={[-5, 1, -1]} rotation-y={Math.PI / 2} scale={[20, 1, 1]} />
        <Lightformer intensity={1} color="#8be" position={[5, 1, -1]} rotation-y={-Math.PI / 2} scale={[20, 1, 1]} />
      </Environment>
    </Canvas>
  );
}
