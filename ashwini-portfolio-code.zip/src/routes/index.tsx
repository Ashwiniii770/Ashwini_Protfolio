import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState, useRef, type ReactNode, type MouseEvent } from "react";
import { Github, Linkedin, Mail, Phone, Trophy, Award, Briefcase, GraduationCap, ArrowDown } from "lucide-react";

const HeroScene = lazy(() => import("@/components/HeroScene"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ashwini Mogurampally — Software Engineer Portfolio" },
      { name: "description", content: "B.Tech CSE student, backend engineer and competitive programmer. Python, Java, FastAPI, Kafka, Docker." },
      { property: "og:title", content: "Ashwini Mogurampally — Software Engineer Portfolio" },
      { property: "og:description", content: "Backend engineering, algorithms and real-time systems projects." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const skills = {
  "Languages": ["Python", "Java", "C++", "JavaScript", "TypeScript", "Rust", "Go", "SQL", "Bash"],
  "Backend & Data": ["FastAPI", "Flask", "Spring Boot", "REST APIs", "PostgreSQL", "MySQL", "Redis"],
  "Frontend": ["React", "Node.js"],
  "Tools & Cloud": ["Git", "GitHub Actions", "Docker", "AWS EC2/S3", "Linux", "Kafka", "Spark", "CI/CD"],
  "Core": ["DSA", "Competitive Programming", "Debugging", "Unit Testing", "OOP", "DBMS"],
};

const projects = [
  { name: "PayFlow Pro", tag: "Fraud Detection Gateway", stack: ["Python", "FastAPI", "Scikit-learn", "Docker"], stat: "35%", statLabel: "better precision",
    points: ["Payment REST API with idempotency keys for safe retries.", "Isolation Forest anomaly detection at sub-50 ms inference."] },
  { name: "DataStream Pro", tag: "Real-Time Telemetry Engine", stack: ["Kafka", "Spark", "Python", "Redis"], stat: "50K", statLabel: "events / second",
    points: ["Event-driven pipeline with Kafka partitions and Spark Streaming.", "Redis caching cut database read load by 60%."] },
  { name: "Ride Booking API", tag: "Containerized Service", stack: ["FastAPI", "Docker", "Redis", "AWS EC2"], stat: "5K", statLabel: "concurrent sessions",
    points: ["Stateless REST API with JWT auth and RBAC.", "Redis reduced authorization overhead by 40%."] },
];

function Tilt({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (e: MouseEvent) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(900px) rotateY(${x * 12}deg) rotateX(${-y * 12}deg) translateZ(0)`;
  };
  const leave = () => { if (ref.current) ref.current.style.transform = "perspective(900px) rotateY(0) rotateX(0)"; };
  return <div ref={ref} onMouseMove={move} onMouseLeave={leave} className={`transition-transform duration-200 ease-out ${className}`}>{children}</div>;
}

function Section({ id, label, title, children }: { id: string; label: string; title: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-6 py-24">
      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary">{label}</p>
      <h2 className="mt-3 mb-12 text-4xl font-bold md:text-5xl">{title}</h2>
      {children}
    </section>
  );
}

function Index() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <main className="min-h-screen overflow-x-hidden">
      <nav className="fixed inset-x-0 top-0 z-50 glass">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#top" className="font-display text-xl font-extrabold">AM<span className="text-primary">.</span></a>
          <div className="hidden gap-8 text-sm text-muted-foreground md:flex">
            {["about", "skills", "experience", "projects", "achievements", "contact"].map((s) => (
              <a key={s} href={`#${s}`} className="capitalize transition-colors hover:text-foreground">{s}</a>
            ))}
          </div>
        </div>
      </nav>

      <header id="top" className="relative flex min-h-screen items-center">
        <div className="absolute inset-0">
          {mounted && <Suspense fallback={null}><HeroScene /></Suspense>}
        </div>
        <div className="pointer-events-none relative mx-auto w-full max-w-6xl px-6">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.3em] text-accent">Software Engineer · Hyderabad</p>
          <h1 className="text-5xl font-extrabold leading-[0.95] md:text-8xl">Ashwini<br /><span className="text-gradient">Mogurampally</span></h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">Final-year CSE student building fast, correct backend systems — and solving algorithms for fun on CodeChef & LeetCode.</p>
          <div className="pointer-events-auto mt-8 flex flex-wrap gap-3">
            <a href="#projects" className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-transform hover:scale-105">View projects</a>
            <a href="#contact" className="rounded-full glass px-6 py-3 font-semibold transition-colors hover:text-primary">Get in touch</a>
          </div>
        </div>
        <a href="#about" className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-muted-foreground"><ArrowDown /></a>
      </header>

      <Section id="about" label="01 — About" title="Correctness first, then speed.">
        <div className="grid gap-6 md:grid-cols-3">
          {[["8.0", "CGPA / 10"], ["40%", "faster DB queries at internship"], ["12", "defects caught pre-deploy"]].map(([n, l]) => (
            <Tilt key={l} className="glass rounded-2xl p-8">
              <div className="font-display text-5xl font-extrabold text-gradient">{n}</div>
              <p className="mt-2 text-muted-foreground">{l}</p>
            </Tilt>
          ))}
        </div>
        <div className="mt-6 glass rounded-2xl p-8 flex gap-4 items-start">
          <GraduationCap className="mt-1 shrink-0 text-accent" />
          <div>
            <h3 className="text-xl font-bold">Malla Reddy Engineering College for Women</h3>
            <p className="text-muted-foreground">B.Tech in Computer Science & Engineering · Expected May 2027</p>
            <p className="mt-2 text-sm text-muted-foreground">DSA · OOP · DBMS · Operating Systems · Computer Networks</p>
          </div>
        </div>
      </Section>

      <Section id="skills" label="02 — Skills" title="Toolbox">
        <div className="grid gap-6 md:grid-cols-2">
          {Object.entries(skills).map(([cat, list]) => (
            <Tilt key={cat} className="glass rounded-2xl p-6">
              <h3 className="mb-4 text-lg font-bold">{cat}</h3>
              <div className="flex flex-wrap gap-2">
                {list.map((s) => <span key={s} className="rounded-full bg-secondary px-3 py-1 text-sm">{s}</span>)}
              </div>
            </Tilt>
          ))}
        </div>
      </Section>

      <Section id="experience" label="03 — Experience" title="Where I've shipped">
        <Tilt className="glass rounded-2xl p-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex gap-4">
              <Briefcase className="mt-1 text-primary" />
              <div>
                <h3 className="text-2xl font-bold">Software Development Engineer Intern</h3>
                <p className="text-muted-foreground">Cognifyz Technologies · Hyderabad (Remote)</p>
              </div>
            </div>
            <span className="rounded-full bg-secondary px-4 py-1 text-sm">Jan 2026 – Mar 2026</span>
          </div>
          <ul className="mt-6 space-y-3 text-muted-foreground">
            <li>▹ Debugged backend code, wrote unit tests and reviewed peers' code — resolved 12 defects before deployments.</li>
            <li>▹ Refactored Python & Java REST modules and tuned PostgreSQL indexes, cutting query times by 40%.</li>
            <li>▹ Automated Docker builds & deploys with GitHub Actions CI/CD, reducing release overhead by 35%.</li>
            <li>▹ Documented endpoints and OpenAPI schemas, reducing onboarding time by 30%.</li>
          </ul>
        </Tilt>
      </Section>

      <Section id="projects" label="04 — Projects" title="Things I've built">
        <div className="grid gap-6 md:grid-cols-3">
          {projects.map((p) => (
            <Tilt key={p.name} className="glass flex flex-col rounded-2xl p-6">
              <div className="font-display text-4xl font-extrabold text-gradient">{p.stat}</div>
              <p className="text-xs uppercase tracking-widest text-muted-foreground">{p.statLabel}</p>
              <h3 className="mt-6 text-2xl font-bold">{p.name}</h3>
              <p className="text-sm text-accent">{p.tag}</p>
              <ul className="mt-4 flex-1 space-y-2 text-sm text-muted-foreground">{p.points.map((x) => <li key={x}>▹ {x}</li>)}</ul>
              <div className="mt-6 flex flex-wrap gap-2">{p.stack.map((s) => <span key={s} className="rounded-md border px-2 py-0.5 text-xs">{s}</span>)}</div>
            </Tilt>
          ))}
        </div>
      </Section>

      <Section id="achievements" label="05 — Achievements" title="Recognition">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="glass rounded-2xl p-6 space-y-4">
            {["Top 15 Finalist, MSME Innovation Challenge 2025 (100+ teams)", "Smart India Hackathon Finalist — led a 5-member team", "Built & pitched a working prototype in 48 hours at MRECW International Hackathon"].map((a) => (
              <div key={a} className="flex gap-3"><Trophy className="shrink-0 text-glow" size={20} /><p>{a}</p></div>
            ))}
          </div>
          <div className="glass rounded-2xl p-6 space-y-4">
            {["Cisco PCAP", "Cisco Linux Unhatched", "Infosys Python Clean Coding", "Deloitte Cyber Job Simulation"].map((c) => (
              <div key={c} className="flex gap-3"><Award className="shrink-0 text-accent" size={20} /><p>{c}</p></div>
            ))}
          </div>
        </div>
      </Section>

      <Section id="contact" label="06 — Contact" title="Let's build something.">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            [Mail, "ashwinimogurampally07@gmail.com", "mailto:ashwinimogurampally07@gmail.com"],
            [Phone, "+91 63030 44152", "tel:+916303044152"],
            [Linkedin, "LinkedIn", "https://linkedin.com/in/ashwini-mogurampally-15b1ab397"],
            [Github, "github.com/Ashwinii770", "https://github.com/Ashwinii770"],
          ].map(([Icon, label, href]) => {
            const I = Icon as typeof Mail;
            return (
              <a key={label as string} href={href as string} target="_blank" rel="noreferrer" className="glass flex items-center gap-4 rounded-2xl p-6 transition-colors hover:text-primary">
                <I /> <span className="break-all">{label as string}</span>
              </a>
            );
          })}
        </div>
      </Section>

      <footer className="border-t py-8 text-center text-sm text-muted-foreground">© 2026 Ashwini Mogurampally</footer>
    </main>
  );
}
